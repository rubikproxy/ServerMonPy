from .main import main

__version__ = "0.1.0"
__author__ = "sanjay"
__email__ = "rubikproxy@gmail.com"

__all__ = ["main"]
