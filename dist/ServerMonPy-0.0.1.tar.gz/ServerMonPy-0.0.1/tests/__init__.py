# Create an empty __init__.py file in the test directory
# This can be done using the open function and the '__init__.py' file name

with open('tests/__init__.py', 'w') as f:
    pass
